#ifndef MFPCAMLE_CLASS
#define MFPCAMLE_CLASS

#include <RcppArmadillo.h>
#include <vector>
#include <cmath>
using namespace Rcpp;
using namespace arma;

class mfpcaMLE{
public:
    
    // Ordered by sample n = 1, ..., N
    // bMatLarge, sparse b-spline matrix, band * df_spline columns
    // sCount_, number of obs points in each sample
    // length(y_): total number of obs points
    // length(sCount_): total number of obs
    mfpcaMLE(vec y_, mat bMatLarge, 
             double sigmaSq_, vec sCount_);
    // we might have further speed improvment with refinement of bMatLarge?
    
    
    void set_penaltyMatrix(mat Gamma_){
        Gamma = Gamma_;
    }
    
    void set_tuningParameter(double mu2_){
        //mu1 = mu1_;
        mu2 = mu2_;
    }
    
    int get_totalDF(){ return totalDF;}
    double get_sigmaSq(){return std::exp(sigmaSqLog);}
    
    //newly add CV
    void setCVFold(vec cvFold_);
    void activateCV(int cv_);
    
    // the objective and the first order gradient 
    // in the Euclidean space without penalty
    // These two functions are used for initialization
    double objF_Euc(mat S);
    mat gradF_Euc(mat S);

    // on the manifold
    double objF(List UWUt);
    double outOfBagError(List UWUt);
    List gradF(List UWUt);
    
    // Params (0) alpha: conservative rate
    // (1) beta: backtracking shrinkage rate
    // (2) epsilon: accuracy
    // (3) verbose: 0, 1, 2 level of details
    void updateSigmaSq(List UWUt, vec params);
    
    
    
private:
    //  total sample size;
    // total degree of freedom. S and UWUt are both DF-by-DF matrices.
    size_t totalS, totalDF;
    size_t nTotal; // total obs points
    vec sCount;
    // add new private mat
    mat bMatLarge_;
    
    //tuning parameters on  smoothness
    double  mu2; //mu1, on rank and
    double sigmaSqLog; // measurement error, log of sigma squared
    // vec sCount;
    std::vector<mat> BmatList;
    std::vector<vec> yVecList;
    mat Gamma;
    
    // Derived, Euclidean
    std::vector<mat> BtBList;
    mat BtZBSum;
    
    // Derived MLE
    std::vector<mat> BtBListMLE; // B_n^TB_n
    std::vector<vec> BtYListMLE; // B_n^Ty_n
    std::vector<double> YtYListMLE; // y_n^Ty_n
    mat BtBSumMLE;
    
    // CurrentCV index
    vec cvFold;
    int currentCV;
    
    
    vec updateSigmaSqGradient(List UWUt);
    double updateSigmaSqBackTracking(vec res, List UWUt, 
                                     double alpha, double beta,
                                     double sigma,
                                     int verbose);
    
    // Compute the covariance matrix for the i-th observation
    // from Euclidean matrix
    inline mat computePi(const mat& S, const int &i){
        mat Pi;
        Pi = BmatList.at(i) * S * BmatList.at(i).t();
        Pi.diag() += exp(sigmaSqLog);
        return Pi;
    }
    
    // Compute the covariance matrix for the i-th observation
    // from Manifold matrix
    inline mat computePi(const mat& U, const mat& W, const int &i){
        mat Pi;
        Pi = BmatList.at(i) * U;
        Pi = Pi * W * Pi.t();
        Pi.diag() += exp(sigmaSqLog);
        return Pi;
    }
    

    // Compute the negative loglikelihood for the i-th observation.
    inline double computeNegLogliki(const mat& U, 
                                    const double& logdetW, 
                                    const mat& sigmaSqWInv,
                                    const int &i){
        double nlogLik, nlogLik2;
        vec rn2;
        
        
        mat Zn, ZnChol;
        Zn = sigmaSqWInv + U.t() * BtBListMLE.at(i) * U; //W
        ZnChol = chol(Zn, "lower");
        
        
        // log determinant
        nlogLik = sigmaSqLog * (sCount(i) - U.n_cols) +
            2.0*sum(log(abs(ZnChol.diag()) )) + logdetW; //W
        // trace
        rn2 = solve(ZnChol, U.t() * BtYListMLE.at(i));
        
        nlogLik2 = YtYListMLE.at(i) - sum(rn2 % rn2);
        nlogLik2 *= exp(-sigmaSqLog);

        nlogLik += nlogLik2;
        return nlogLik;
    }
    
    // Compute the negative of the summand in K
    inline mat computeKSummand(const mat& U, 
                               const mat& sigmaSqWInv,
                               const int &i){
        
        mat rn1, rn2, kn2;
        mat Zn, ZnChol, Ki;
        
        Zn = sigmaSqWInv + U.t() * BtBListMLE.at(i) * U; //W
        ZnChol = chol(Zn, "lower");
        
        rn1 = solve(ZnChol, U.t() * BtBListMLE.at(i));
        rn2 = solve(ZnChol, U.t() * BtYListMLE.at(i));
        Ki = - rn1.t() * rn1;
        kn2 = BtYListMLE.at(i) - rn1.t() * rn2;
        Ki -= kn2 * kn2.t() * exp(-sigmaSqLog);
        
        return Ki;
    }
};



#endif
