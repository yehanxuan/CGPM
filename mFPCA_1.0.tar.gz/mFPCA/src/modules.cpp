#include "mfpcaMLE.hpp"
#include "univariateFPCAv2.hpp"
#include "VonNeumannDiv.hpp"
#include "frobDiverg.hpp"
#include "Bregman.hpp"
#include "Power.hpp"

RCPP_MODULE(MFPCA){
    class_<uFPCAClassv2>("uFPCAClassv2")
        .constructor<vector<vec>,  vector<mat > >()
        .method("objF", &uFPCAClassv2::objF)
        .method("gradF", &uFPCAClassv2::gradF)
        .method("objF_Euc", &uFPCAClassv2::objF_Euc)
        .method("gradF_Euc", &uFPCAClassv2::gradF_Euc)
        .method("set_penaltyMatrix", &uFPCAClassv2::set_penaltyMatrix)
        .method("set_tuningParameter", &uFPCAClassv2::set_tuningParameter)
        .method("get_totalDF", &uFPCAClassv2::get_totalDF)
        .method("setCVFold", &uFPCAClassv2::setCVFold)
        .method("activateCV", &uFPCAClassv2::activateCV)
        .method("outOfBagError", &uFPCAClassv2::outOfBagError)
    ;

    class_<mfpcaMLE>("mfpcaMLE")
        .constructor<vec,  mat, double, vec>()
        .method("objF", &mfpcaMLE::objF)
        .method("gradF", &mfpcaMLE::gradF)
        .method("objF_Euc", &mfpcaMLE::objF_Euc)
        .method("gradF_Euc", &mfpcaMLE::gradF_Euc)
        .method("set_penaltyMatrix", &mfpcaMLE::set_penaltyMatrix)
        .method("set_tuningParameter", &mfpcaMLE::set_tuningParameter)
        .method("get_totalDF", &mfpcaMLE::get_totalDF)
        .method("updateSigmaSq", &mfpcaMLE::updateSigmaSq)
        .method("get_sigmaSq", &mfpcaMLE::get_sigmaSq)
        .method("setCVFold", &mfpcaMLE::setCVFold)
        .method("activateCV", &mfpcaMLE::activateCV)
        .method("outOfBagError", &mfpcaMLE::outOfBagError)
    ;
    
    
    class_<mfpcaVNDiv>("mfpcaVNDiv")
        .constructor<vec, mat, double, vec>()
        .method("objF", &mfpcaVNDiv::objF)
        .method("gradF", &mfpcaVNDiv::gradF)
        .method("objF_Euc", &mfpcaVNDiv::objF_Euc)
        .method("gradF_Euc", &mfpcaVNDiv::gradF_Euc)
        .method("set_penaltyMatrix", &mfpcaVNDiv::set_penaltyMatrix)
        .method("set_tuningParameter", &mfpcaVNDiv::set_tuningParameter)
        .method("get_totalDF", &mfpcaVNDiv::get_totalDF)
        .method("updateSigmaSq", &mfpcaVNDiv::updateSigmaSq)
        .method("get_sigmaSq", &mfpcaVNDiv::get_sigmaSq)
        .method("setCVFold", &mfpcaVNDiv::setCVFold)
        .method("activateCV", &mfpcaVNDiv::activateCV)
        .method("outOfBagError", &mfpcaVNDiv::outOfBagError)
        ;
    
    class_<frobDiverg>("frobDiverg")
        .constructor<vec, mat, double, vec>()
        .method("objF", &frobDiverg::objF)
        .method("gradF", &frobDiverg::gradF)
        .method("objF_Euc", &frobDiverg::objF_Euc)
        .method("gradF_Euc", &frobDiverg::gradF_Euc)
        .method("set_penaltyMatrix", &frobDiverg::set_penaltyMatrix)
        .method("set_tuningParameter", &frobDiverg::set_tuningParameter)
        .method("get_totalDF", &frobDiverg::get_totalDF)
        .method("updateSigmaSq", &frobDiverg::updateSigmaSq)
        .method("get_sigmaSq", &frobDiverg::get_sigmaSq)
        .method("setCVFold", &frobDiverg::setCVFold)
        .method("activateCV", &frobDiverg::activateCV)
        .method("outOfBagError", &frobDiverg::outOfBagError)
        ;
    
    class_<mfpcaBreg>("mfpcaBreg")
        .constructor<vec, mat, double, vec, double>()
        .method("objF", &mfpcaBreg::objF)
        .method("gradF", &mfpcaBreg::gradF)
        .method("set_penaltyMatrix", &mfpcaBreg::set_penaltyMatrix)
        .method("set_tuningParameter", &mfpcaBreg::set_tuningParameter)
        .method("get_totalDF", &mfpcaBreg::get_totalDF)
        .method("updateSigmaSq", &mfpcaBreg::updateSigmaSq)
        .method("get_sigmaSq", &mfpcaBreg::get_sigmaSq)
        .method("setCVFold", &mfpcaBreg::setCVFold)
        .method("activateCV", &mfpcaBreg::activateCV)
        .method("outOfBagError", &mfpcaBreg::outOfBagError)
    ;
    
    class_<mfpcaPower>("mfpcaPower")
        .constructor<vec, mat, double, vec, double>()
        .method("objF", &mfpcaPower::objF)
        .method("gradF", &mfpcaPower::gradF)
        .method("set_penaltyMatrix", &mfpcaPower::set_penaltyMatrix)
        .method("set_tuningParameter", &mfpcaPower::set_tuningParameter)
        .method("get_totalDF", &mfpcaPower::get_totalDF)
        .method("updateSigmaSq", &mfpcaPower::updateSigmaSq)
        .method("get_sigmaSq", &mfpcaPower::get_sigmaSq)
        .method("setCVFold", &mfpcaPower::setCVFold)
        .method("activateCV", &mfpcaPower::activateCV)
        .method("outOfBagError", &mfpcaPower::outOfBagError)
    ;
}
