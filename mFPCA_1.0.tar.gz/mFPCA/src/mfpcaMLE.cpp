#include "mfpcaMLE.hpp"

void mfpcaMLE::setCVFold(vec cvFold_){
    cvFold = cvFold_;
}

void mfpcaMLE::activateCV(int cv_){
    currentCV = cv_;
}
//' Initialize the MFPCA loss function. 
//' The only requirement is the sample groups are ordered.
//' 
//' @param y_ All the stacked observation points. The mean curve has been subtracted.
//' @param bMatLarge The stacked basis matrix
//' @param sigmaSq_ The standard variance of the measurement error
//' @param sCount The number of obs points for each obs group
mfpcaMLE::mfpcaMLE(vec y_, mat bMatLarge,
                   double sigmaSq_, vec sCount_){
    
    
    bMatLarge_ = bMatLarge;
    sCount = sCount_;
    totalS = sCount.size();
    
    // Init Cross-validation
    currentCV = -1;
    cvFold = ones<vec>(totalS);
    
    int startI = -1, endI = -1;
    double m_n = 0;
    vec yn;
    mat Bn, Zn, BnTBn;
    
    totalDF = bMatLarge.n_cols;
    BtZBSum = mat(totalDF, totalDF, fill::zeros);
    BtBSumMLE = mat(totalDF, totalDF, fill::zeros);
    
    sigmaSqLog = std::log(sigmaSq_);
    nTotal = 0;
    for(int n=0; n < totalS; n++){
        m_n = sCount(n);
        nTotal += m_n;
        startI = endI + 1;
        endI = startI + m_n - 1;
        
        yn = y_(span(startI, endI));
        Bn = bMatLarge.rows(startI, endI);
        
        BmatList.push_back(Bn);
        yVecList.push_back(yn);
        
        
        // For initial computation with least square loss
        // and euclidean geometry.
        // Only compute with initial value of sigmaSq
        BnTBn = Bn.t() * Bn;
        
        // Computation saving for MLE
        YtYListMLE.push_back(dot(yn, yn) );
        BtBListMLE.push_back(BnTBn);
        BtYListMLE.push_back(Bn.t() * yn);
        BtBSumMLE += BnTBn;
        
        
        // Computation saving for least square
        // In the document Zn = yn * yn.t() - sigmaSq I
        BtBList.push_back(BnTBn / m_n);
        Zn =  yn * yn.t();
        Zn.diag() -= sigmaSq_;
        BtZBSum += Bn.t() * Zn * Bn / (m_n * m_n);
    }
    
}// MFPCALoss
//out of bag error
double mfpcaMLE::outOfBagError(List UWUt){
    arma::mat U,W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss = 0;
    int activeN = 0;
    double logdetW, signW;
    log_det(logdetW, signW, W);
    
    // sigma^2 * W^{-1}
    mat sigmaSqWInv = exp(sigmaSqLog) * inv(W);
    
    for (int i = 0; i < totalS; i++ ){
        if (cvFold[i] != currentCV ) continue;
        activeN++;
        loss += computeNegLogliki(U, logdetW, sigmaSqWInv, i);
    }
    loss /=  static_cast<double>(activeN);
    return loss;
}




// Input list: UWUt = U X W
// Output: the penalized negative log-likelihood
double mfpcaMLE::objF(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss = 0;
    int activeN = 0;
    double logdetW, signW;
    log_det(logdetW, signW, W);
    
    // sigma^2 * W^{-1}
    mat sigmaSqWInv = exp(sigmaSqLog) * inv(W);
    
    // try{
    // Accumulate loglikelihood
    for(int i = 0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        loss += computeNegLogliki(U, logdetW, sigmaSqWInv, i);
    }
    loss /= static_cast<double>(activeN);
    // }catch(const std::exception& e){
    //     //vec eigval = eig_sym(W);
    //     Rcpp::Rcerr <<  " Obj "  << endl;
    //     //throw(e);
    // }
    
    // penalty
    //loss += mu1 * trace(W);
    loss += mu2 * dot(U, Gamma*U);
    return loss;
}

// Input list: UWUt = U X W
// Output list: gradient w.r.t U and W respectively.
List mfpcaMLE::gradF(List UWUt){
    arma::mat U, W, comp1, comp2;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));

    // sigma^2 * W^{-1}
    mat sigmaSqWInv = exp(sigmaSqLog) * inv(W);
    
    arma::mat coreGrad, grad1, grad2;
    coreGrad = zeros(totalDF, totalDF);
    int activeN = 0;
  /*  size_t Total_CV = 0;
    int startJ = -1, endJ = -1;
    double m_i = 0; */
    //try{
    mat BtBSumMLECV;
    BtBSumMLECV = mat(totalDF, totalDF, fill::zeros);
    
    // mat Bn_CV, BnTBn_CV;
        for(int i = 0; i < totalS; i++){
            // Accumulate the negative summand in K
            if (cvFold[i] == currentCV) continue;
            activeN++;
            coreGrad += computeKSummand(U, sigmaSqWInv, i);
            
            // compute BtBSumMLE for CV
           /*  m_i = sCount(i);
            Total_CV += m_i;
            startJ = endJ + 1;
            endJ = startJ + m_i - 1;
            
           // yn = y_(span(startI, endI));
            Bn_CV = bMatLarge_.rows(startJ, endJ);
            BnTBn_CV = Bn_CV.t() * Bn_CV;   */
            BtBSumMLECV += BtBListMLE.at(i);
        }
    // }catch(const std::exception& e){
    //     vec eigval = eig_sym(W);
    //     Rcpp::Rcerr << eigval.max()  << " Grad " << eigval.min() << endl;
    // }
    coreGrad += BtBSumMLECV;
        
    coreGrad *= exp(-sigmaSqLog);
    coreGrad /= static_cast<double>(activeN);
    
    grad2 = coreGrad * U;
    grad1 = (2.0) * grad2 * W;
    double alpha = 2.0;
    grad2 = alpha * U.t() * grad2;
    
    grad1 += (2.0*mu2) * Gamma * U;
    //grad2.diag() += mu1;
    //Rcpp::Rcout << "Grad = " << norm(grad1,"fro") << " " << norm(grad2, "fro");
    List gradL = List::create(grad1, grad2);
    return gradL;
}




void mfpcaMLE::updateSigmaSq(List UWUt, vec params){
    
    double alpha, beta, epsilon, sigma;
    vec res;
    double lambda;
    
    int iter = 0, verbose;
    alpha = params(0);
    beta = params(1);
    sigma = params(2);
    epsilon = params(3);
    verbose = params(4);
    
    do{
        res = updateSigmaSqGradient(UWUt); // compute gradient and hessian
        lambda = updateSigmaSqBackTracking(res, UWUt, alpha, beta, sigma, verbose); // update by back tracking
        if(verbose > 0) Rcout << "Iter = " << iter << "; lambda = " 
                              << lambda << std::endl;
        iter++;
    } while (iter < 30 && lambda > epsilon);
}


// Output: first and second order gradient w.r.t. gamma = log(sigma^2)
vec mfpcaMLE::updateSigmaSqGradient(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    vec res(2, fill::zeros);
    int activeN = 0;
    
    mat Pi, PiInv;
    vec tmpY;
    mat tmpB;
    double grad = 0.0, hess = 0.0;
    for(int i = 0; i < totalS; i++){
        // add cv 
        if (cvFold[i] == currentCV ) continue;
        activeN++;
        Pi = computePi(U, W, i);
        //PiChol = chol(Pi, "lower");
        //tmpY = solve(trimatl(PiChol), yVecList.at(i));
        PiInv = Pi.i();
        tmpY = PiInv * yVecList.at(i);
        //grad += - dot(tmpY, PiInv * tmpY) + sum(PiInv.diag());
        grad += - dot(tmpY, tmpY) + sum(PiInv.diag());
        hess += (2.0) * dot(tmpY, PiInv * tmpY) - dot(PiInv, PiInv);
    }
    grad /= static_cast<double>(activeN);
    hess /= static_cast<double>(activeN);
    res(0) = grad * std::exp(sigmaSqLog);
    res(1) = grad * std::exp(sigmaSqLog) + hess * std::exp(2 * sigmaSqLog);
    return res;
}


double mfpcaMLE::updateSigmaSqBackTracking(vec res, List UWUt, 
                                           double alpha, double beta,
                                           double sigma,
                                           int verbose){
    double grad, hess;
    grad = res(0);
    hess = res(1);
    
    double objV, objVOld, sigmaSqLogOld, lambda;
    double stepsize = 10, expectedDesc, actualDesc;
    int iterInner = 0;
    
    // the newton decrement, in Boyd's book
    lambda = grad * grad / hess;
    expectedDesc = lambda / beta * alpha * sigma;
    sigmaSqLogOld = sigmaSqLog;
    objVOld = objF(UWUt);
    do{
        sigmaSqLog = sigmaSqLogOld - stepsize * grad / hess;
        // the obj fun will be computed with this new sigmaSqLog
        objV = objF(UWUt);
        actualDesc = objVOld - objV;
        iterInner++;
        stepsize *= beta;
        expectedDesc *= beta;
        if(verbose > 1)
            Rcout << iterInner << " " << expectedDesc << 
                " " << actualDesc << std::endl;
    }while(iterInner < 50 & actualDesc < expectedDesc);  //iterInner too many or less
    
    return lambda;  
}


// Objective for Euclidean S withouth penalty.
double mfpcaMLE::objF_Euc(mat S){
    // double loss = 0;
    // summation of negative log-likelihood
    // mat  Pi;
    // for(int i = 0; i < totalS; i++){
    //     Pi = computePi(S, i);
    //     loss += computeLogliki(Pi, i);
    // }
    // return loss;
    
    // for the initialization, we can not ensure the positive
    // definteness of the matrix, so we use least square loss
    // Only compute with the initial value of sigmaSq
    
    arma::mat BBSBB;
    double loss = 0;
    // quadratic loss
    for(int i = 0; i < totalS; i++){
        BBSBB =  BtBList.at(i) * S * BtBList.at(i);
        loss += dot(BBSBB, S);
    }
    loss -= 2.0 * dot(BtZBSum, S);
    loss /= (2*totalS);
    return loss;
    
}


// Gradient for Euclidean S withouth penalty.
mat mfpcaMLE::gradF_Euc(mat S){
    // mat  gradS, Pi;
    // gradS = zeros(totalDF, totalDF);
    // for(int i = 0; i < totalS; i++){
    //     Pi = computePi(S, i);
    //     // Compute the negative of the summand in K
    //     gradS += computeKSummand(Pi, i);
    // }
    // return -gradS;
    
    arma::mat gradS;
    gradS = - BtZBSum;
    
    for(int i = 0; i < totalS; i++)
        gradS +=  BtBList.at(i) * S * BtBList.at(i);
    
    gradS /= totalS;
    return gradS;
}


