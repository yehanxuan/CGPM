#include "VonNeumannDiv.hpp"


void mfpcaVNDiv::setCVFold(vec cvFold_){
    cvFold = cvFold_;
}

void mfpcaVNDiv::activateCV(int cv_){
    currentCV = cv_;
}

mfpcaVNDiv::mfpcaVNDiv(vec y_, mat bMatLarge,
                       double sigmaSq_, vec sCount_){
    bMatLarge_ = bMatLarge;
    sCount = sCount_;
    totalS = sCount.size();
    
    momentum = 0.9;
    v = 0.0;
    lr = 0.05;
    // Init Cross-validation
    currentCV = -1;
    cvFold = ones<vec>(totalS);
    
    int startI = -1, endI = -1;
    double m_n = 0;
    mat Zn, Bn, BnTBn;
    vec yn;
    totalDF = bMatLarge.n_cols;
    BtZBSum = mat(totalDF, totalDF, fill::zeros);
    
    
    sigmaSqLog = std::log(sigmaSq_);
    nTotal = 0;
    
    for (int n = 0; n < totalS; n++){
        m_n = sCount(n);
        nTotal += m_n;
        startI = endI + 1;
        endI = startI +m_n - 1;
        yn = y_(span(startI, endI));
        Bn = bMatLarge.rows(startI, endI);
        
        BmatList.push_back(Bn);
        yVecList.push_back(yn);
        
        BnTBn = Bn.t() * Bn;
         // a matrix?
        
        BtBList.push_back(BnTBn / m_n);
        Zn = yn * yn.t();
        SList.push_back(Zn);
        Zn.diag() -= sigmaSq_; 
        
        BtZBSum += Bn.t() * Zn * Bn /(m_n * m_n);
        }
    
    
    
}


double mfpcaVNDiv::outOfBagError(List UWUt){
    arma:mat U,W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss = 0;
    int activeN = 0;
    
    double sigmaSq = exp(sigmaSqLog);
    for (int i = 0; i < totalS; i++){
        if (cvFold[i] != currentCV ) continue;
        activeN++;
        loss += computeDiv(U, W, sigmaSq, i);
        }
    loss /= static_cast<double>(activeN);
    return loss;
}

double mfpcaVNDiv::objF(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss = 0;
    int activeN = 0;

    
    
    // sigma^2 * W^{-1}
    double sigmaSq = exp(sigmaSqLog);
    for(int i = 0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        loss += computeDiv(U, W, sigmaSq, i);
    }
    loss /= static_cast<double>(activeN);
    // }catch(const std::exception& e){
    //     //vec eigval = eig_sym(W);
    //     Rcpp::Rcerr <<  " Obj "  << endl;
    //     //throw(e);
    // }
    
    // penalty
    //loss += mu1 * trace(W);
    loss += mu2 * dot(U, Gamma*U);
    return loss;
}


List mfpcaVNDiv::gradF(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    arma::mat coreGrad, grad1, grad2;
    coreGrad = zeros(totalDF, totalDF);
    int activeN = 0;
    
    double sigmaSq = exp(sigmaSqLog);
    for (int i=0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        mat Sigma = zeros(sCount(i), sCount(i));
        Sigma = BmatList.at(i)* U * W * U.t() * BmatList.at(i).t();
        Sigma += sigmaSq * eye(sCount(i), sCount(i));
        coreGrad += computeCore(Sigma, i);
        
    }
    
    coreGrad /= activeN;
    grad2 = coreGrad * U;
    grad1 = 2 * grad2 * W;
    grad2 = U.t() * grad2;
    
    grad1 += (2*mu2) * Gamma * U;
    List gradL = List::create(grad1, grad2);
    return gradL;
    
}



void mfpcaVNDiv::updateSigmaSq(List UWUt, vec params){
  double alpha, beta, epsilon, sigma;
  double res; 
  double lambda;
  
  int iter = 0, verbose;
  alpha = params(0);
  beta = params(1);
  sigma = params(2);
  epsilon = params(3);
  verbose = params(4);
  
  do {
    res = updateSigmaSqGradient(UWUt);
    lambda = updateSigmaSqBackTracking(res, UWUt, alpha, beta, sigma, verbose);
    if (verbose > 0) Rcout << "Iter = " << iter << "; lambda = " << lambda <<std::endl;
    iter++;
  } while (iter < 30 && lambda > epsilon);
}


/* void mfpcaVNDiv::updateSigmaSq(List UWUt, vec params){
    double res, grad;
    int iter = 0;
    double decay, verbose;
    lr = params(0);
    //lr = params(1);
    momentum = params(1);
    verbose = params(2);
    double sigmaSqOld = exp(sigmaSqLog);
    double sigmaSq;
    grad = updateSigmaSqGradient(UWUt);
    v = momentum * v + grad;
    sigmaSq = sigmaSqOld - lr * v;
    if (sigmaSq < 0 ) sigmaSq = 1e-4;
    //lr = lr*decay;
    sigmaSqLog = log(sigmaSq);
    if(verbose > 0) Rcout << "Iter = " << iter << "; grad = " 
                          << grad << std::endl;
}  */

 /* do {
        grad = updateSigmaSqGradient(UWUt);
        sigmaSq = sigmaSqOld - stepsize * grad;
        if (sigmaSq < 0 ) sigmaSq = 1e-7;
        stepsize = stepsize*decay;
        sigmaSqLog = log(sigmaSq);
        iter++;
        if(verbose > 0) Rcout << "Iter = " << iter << "; grad = " 
                              << grad << std::endl;
    } while (iter < 30);   */
    
/*    int iter = 0, verbose;
    alpha = params(0);
    beta = params(1);
    sigma = params(2);
    epsilon = params(3);
    verbose = params(4);
    
    do {
        res = updateSigmaSqGradient(UWUt); // compute gradient and hessian
        lambda = updateSigmaSqBackTracking(res, UWUt, alpha, beta, sigma, verbose);
        if (verbose > 0) Rcout << "Iter = " << iter << "; lambda = " 
                               << lambda << std::endl;
        iter++;
    } while (iter < 30 && lambda > epsilon); */ 




double mfpcaVNDiv::updateSigmaSqGradient(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double res= 0.0;
    int activeN = 0;
    double sigmaSq = exp(sigmaSqLog);
    double grad = 0.0;
  
    for (int i = 0; i < totalS; i++){
        if (cvFold[i] == currentCV ) continue;
        activeN++;
        mat Sigma = zeros(sCount(i), sCount(i));
        Sigma = BmatList.at(i)* U * W * U.t() * BmatList.at(i).t();
        Sigma += sigmaSq * eye(sCount(i), sCount(i));
        vec eigval;
        mat eigvec;
        eig_sym(eigval, eigvec, Sigma);
        vec h = eigvec.t() * yVecList.at(i);
        mat PhiG_n = DerivMat(eigval);
        int n = eigval.n_elem;
        grad += trace(eye(n,n) - ( h * h.t() ) % PhiG_n) ;
    }
    grad /= activeN;
    res = grad * std::exp(sigmaSqLog);
    return res;
}


double mfpcaVNDiv::updateSigmaSqBackTracking(double res, List UWUt,
                                             double alpha, double beta,
                                             double sigma,
                                             int verbose){
  double grad;
  grad = res;
  
  double objV, objVOld, sigmaSqLogOld, lambda;
  double stepsize = 5, expectedDesc, actualDesc;
  int iterInner = 0;
  
  lambda = grad * grad;
  expectedDesc = lambda / beta * alpha * sigma;
  sigmaSqLogOld = sigmaSqLog;
  objVOld = objF(UWUt);
  do{
    sigmaSqLog = sigmaSqLogOld - stepsize * grad ;
    objV = objF(UWUt);
    actualDesc = objVOld - objV;
    iterInner++;
    stepsize *= beta;
    expectedDesc *= beta;
    if( verbose > 1)
      Rcout << iterInner << " " << expectedDesc << 
        " " << actualDesc << std::endl;
  } while (iterInner < 50 & actualDesc < expectedDesc);
  
  return lambda;
}



//double mfpcaVNDiv::updateSigmaSq()

double mfpcaVNDiv::objF_Euc(mat S){
    // double loss = 0;
    // summation of negative log-likelihood
    // mat  Pi;
    // for(int i = 0; i < totalS; i++){
    //     Pi = computePi(S, i);
    //     loss += computeLogliki(Pi, i);
    // }
    // return loss;
    
    // for the initialization, we can not ensure the positive
    // definteness of the matrix, so we use least square loss
    // Only compute with the initial value of sigmaSq
    
    arma::mat BBSBB;
    double loss = 0;
    // quadratic loss
    for(int i = 0; i < totalS; i++){
        BBSBB =  BtBList.at(i) * S * BtBList.at(i);
        loss += dot(BBSBB, S);
    }
    loss -= 2.0 * dot(BtZBSum, S);
    loss /= (2*totalS);
    return loss;
    
}


// Gradient for Euclidean S withouth penalty.
mat mfpcaVNDiv::gradF_Euc(mat S){
    arma::mat gradS;
    gradS = - BtZBSum;
    
    for(int i = 0; i < totalS; i++)
        gradS +=  BtBList.at(i) * S * BtBList.at(i);
    
    gradS /= totalS;
    return gradS;
}

