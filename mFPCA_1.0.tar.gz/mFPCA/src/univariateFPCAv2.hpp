#ifndef UFPCACLASSV2_CLASS
#define UFPCACLASSV2_CLASS

#include <RcppArmadillo.h>
#include <vector>
using namespace Rcpp;
using namespace arma;
using namespace std;

class uFPCAClassv2{
public:
    
    // y_ : list of observed values
    // bMatList: list of 
    uFPCAClassv2(vector<vec> y_, vector<mat> bMatList);
    // we might have further speed improvment with refinement of bMatLarge?
    
    
    void set_penaltyMatrix(mat Gamma_){
        Gamma = Gamma_;
    }

    void set_tuningParameter(double mu1_){
        mu1 = mu1_;
    }
    
    int get_totalDF(){ return totalDF;}
    
    void setCVFold(vec cvFold_);
    void activateCV(int cv_);

    // the objective and the first order gradient 
    // in the Euclidean space without penalty
    // These two functions are used for initialization
    double objF_Euc(mat S);
    mat gradF_Euc(mat S);
    
    // on the manifold
    double objF(List UWUt);
    List gradF(List UWUt);
    
    
    double outOfBagError(List UWUt);
    

private:
    //  total sample size;
    // total degree of freedom. S and UWUt are both DF-by-DF matrices.
    size_t totalS, totalDF;
    size_t nTotal; // total obs points
    //tuning parameters on rank and smoothness respectively
    double mu1;
    // vec sCount;
    vector<vec> yList;
    vector<mat> bMatList;
    mat  yyBBtSum,yyBBtSum_train, Gamma;
    
    
    mat computeMidterm(vec cvFold, int currentCV, vector<vec> yList, vector<mat> bMatList, int index);
    vec cvFold;
    int currentCV;
//    uvec tmp1;
//    uvec tmp2;
};



#endif
