#ifndef MFPCAPOWER_CLASS
#define MFPCAPOWER_CLASS

#include <RcppArmadillo.h>
#include <vector>
#include <cmath>
using namespace Rcpp;
using namespace arma;

class mfpcaPower{
public:
    // Ordered by sample n = 1, ..., N
    // bMatLarge, sparse b-spline matrix, band * df_spline columns
    // sCount_, number of obs points in each sample
    // length(y_): total number of obs points
    // length(sCount_): total number of obs
    mfpcaPower(vec y_, mat bMatLarge, 
               double sigmaSq_, vec sCount_, double b_);
    // we might have further speed improvment with refinement of bMatLarge?
    
    void set_penaltyMatrix(mat Gamma_){
        Gamma = Gamma_;
    }
    
    void set_tuningParameter(double mu2_){
        //mu1 = mu1_;
        mu2 = mu2_;
    }
    
    int get_totalDF(){ return totalDF;}
    double get_sigmaSq(){return std::exp(sigmaSqLog);}
    
    //newly add CV
    void setCVFold(vec cvFold_);
    void activateCV(int cv_);
    
    // on the manifold
    double objF(List UWUt);
    double outOfBagError(List UWUt);
    List gradF(List UWUt);
    
    void updateSigmaSq(List UWUt, vec params);

private:
    //  total sample size;
    // total degree of freedom. S and UWUt are both DF-by-DF matrices.
    size_t totalS, totalDF;
    size_t nTotal; // total obs points
    vec sCount;
    // add new private mat
    mat bMatLarge_;
    
    double b;
    //tuning parameters on  smoothness
    double  mu2; //mu1, on rank and
    double sigmaSqLog; // measurement error, log of sigma squared
    
    std::vector<mat> BtBList;
    
    std::vector<mat> BmatList;
    std::vector<vec> yVecList;
    mat BtZBSum, Gamma;
    
    // CurrentCV index
    vec cvFold;
    int currentCV;
    
    double updateSigmaSqGradient(List UWUt);
    double updateSigmaSqBackTracking(double res, List UWUt, 
                                     double alpha, double beta,
                                     double sigma,
                                     int verbose); 
    
    inline mat computePi(const mat& U, const mat& W, const int &i){
        mat Pi;
        Pi = BmatList.at(i) * U;
        Pi = Pi * W * Pi.t();
        Pi.diag() += exp(sigmaSqLog);
        return Pi;
    }
    
    inline double getPrec(){
        return sqrt(nextafter(1, std::numeric_limits<double>::infinity()) - 1);
    }
    
    inline mat DerivMat(const vec& eigval){
        mat PhiG_n;
        int n = eigval.n_elem;
        PhiG_n.zeros(n, n);
        double eps = getPrec();
        for (int i = 0; i < eigval.n_elem; i++){
            for (int j=0; j<i; j++){
                if ( abs(eigval(j) - eigval(i)) < eps ){
                    PhiG_n(i, j) = b * pow( eigval(i), -(b+1));
                    PhiG_n(j, i) = PhiG_n(i,j);
                } else {
                    PhiG_n(i, j) = ( -pow(eigval(i), -b) + pow(eigval(j), -b) )/(eigval(i) - eigval(j));
                    PhiG_n(j, i) = PhiG_n(i, j);
                }
            }
        }
        PhiG_n.diag() = b * pow(eigval, -(b+1));
        return PhiG_n;
    }
    
    inline mat computeCore(const mat& Sigma, const int &i){
        vec eigval;
        mat eigvec;
        // Construct derivative of phi(G_n)
        eig_sym(eigval, eigvec, Sigma);
        vec h = eigvec.t() * yVecList.at(i);
        mat PhiG_n;
        PhiG_n = DerivMat(eigval);
        int n = eigval.n_elem;
        mat GradSigma;
        GradSigma = -( h * h.t() ) % PhiG_n;
        GradSigma.diag() += b * pow(eigval, -b);
        mat tmp = BmatList.at(i).t() * eigvec;
        mat coreGrad = tmp * GradSigma * tmp.t();
        return coreGrad;
    }
};

#endif
