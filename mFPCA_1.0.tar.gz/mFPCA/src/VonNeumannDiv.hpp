#ifndef MFPCAVON_CLASS
#define MFPCAVON_CLASS

#include <RcppArmadillo.h>
#include <vector>
#include <cmath>
using namespace Rcpp;
using namespace arma;

class mfpcaVNDiv{
public:
    // Ordered by sample n = 1, ..., N
    // bMatLarge, sparse b-spline matrix, band * df_spline columns
    // sCount_, number of obs points in each sample
    // length(y_): total number of obs points
    // length(sCount_): total number of obs
    mfpcaVNDiv(vec y_, mat bMatLarge, 
             double sigmaSq_, vec sCount_);
    // we might have further speed improvment with refinement of bMatLarge?
    
    void set_penaltyMatrix(mat Gamma_){
        Gamma = Gamma_;
    }
    
    void set_tuningParameter(double mu2_){
        //mu1 = mu1_;
        mu2 = mu2_;
    }
    
    int get_totalDF(){ return totalDF;}
    double get_sigmaSq(){return std::exp(sigmaSqLog);}
    
    //newly add CV
    void setCVFold(vec cvFold_);
    void activateCV(int cv_);
    
    // the objective and the first order gradient 
    // in the Euclidean space without penalty
    // These two functions are used for initialization
    double objF_Euc(mat S);
    mat gradF_Euc(mat S);
    
    // on the manifold
    double objF(List UWUt);
    double outOfBagError(List UWUt);
    List gradF(List UWUt);
    
    void updateSigmaSq(List UWUt, vec params);
    
private:
    //  total sample size;
    // total degree of freedom. S and UWUt are both DF-by-DF matrices.
    size_t totalS, totalDF;
    size_t nTotal; // total obs points
    vec sCount;
    // add new private mat
    mat bMatLarge_;
    
    //tuning parameters on  smoothness
    double  mu2; //mu1, on rank and
    double sigmaSqLog; // measurement error, log of sigma squared
    // vec sCount;
    double momentum;
    double v;
    double lr;
    
    std::vector<mat> BtBList;
    
    std::vector<mat> BmatList;
    std::vector<vec> yVecList;
    mat BtZBSum, Gamma;
    
    //std::vector<mat> SigmaList; 
    std::vector<mat> SList;
    
    // CurrentCV index
    vec cvFold;
    int currentCV;
    
    double updateSigmaSqGradient(List UWUt);
    double updateSigmaSqBackTracking(double res, List UWUt, 
                                     double alpha, double beta,
                                     double sigma,
                                     int verbose); 
    
    inline double computeDiv(const mat& U,
                             const mat& W,
                             const double& sigmaSq,
                             const int &i){
        double value = 0.0;
        mat Sigma = zeros(sCount(i), sCount(i));
        Sigma = BmatList.at(i)* U * W * U.t() * BmatList.at(i).t();
        Sigma += sigmaSq * eye(sCount(i), sCount(i));
        
        vec eigval;
        mat eigvec;
        eig_sym(eigval, eigvec, Sigma);
        vec h = eigvec.t() * yVecList.at(i);
        value = -sum(h % h % log(eigval));
        value += sum(eigval);
        //value = trace(- SList.at(i) * log(Sigma) - Sigma);
        return value;
    }
    
    inline double getPrec(){
        return sqrt(nextafter(1, std::numeric_limits<double>::infinity()) - 1);
    }
    
    inline mat DerivMat(const vec& eigval){
        mat PhiG_n;
        int n = eigval.n_elem;
        PhiG_n.zeros(n, n);
        double eps = getPrec();
        for (int i = 0; i < eigval.n_elem; i++){
            for (int j = 0; j < i ; j++ ){
                if ( abs(eigval(j) - eigval(i)) < eps ){
                    PhiG_n(i, j) = 1/eigval(i);
                    PhiG_n(j, i) = PhiG_n(i, j);
                } else {
                    PhiG_n(i, j) = (log(eigval(i)) - log(eigval(j)))/(eigval(i) - eigval(j));
                    PhiG_n(j, i) = PhiG_n(i, j);
                }
                /*if (j == i){
                    PhiG_n(i, j) = 1/eigval(i);
                }*/
            } 
        }
        PhiG_n.diag() = 1.0/eigval;
        return PhiG_n;
    }
    
    inline mat computeCore(const mat& Sigma, const int &i){
        vec eigval;
        mat eigvec;
        // Construct derivative of phi(G_n)
        eig_sym(eigval, eigvec, Sigma);
        vec h = eigvec.t() * yVecList.at(i);
        mat PhiG_n;
        PhiG_n = DerivMat(eigval);
        int n = eigval.n_elem;
        mat GradSigma;
        GradSigma = eye(n,n) - ( h * h.t() ) % PhiG_n;
        //GradSigma = eigvec * GradSigma * eigvec.t();
        mat tmp = BmatList.at(i).t() * eigvec;
        mat coreGrad = tmp * GradSigma * tmp.t();
        return coreGrad;
    }
    
};

#endif
