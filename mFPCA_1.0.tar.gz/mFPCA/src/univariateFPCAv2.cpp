#include "univariateFPCAv2.hpp"

//' Initialize the FPCA with least squares loss. 
//' 
//' @param y_ List of observation vector. The mean curve has been subtracted.
//' @param bMatList_ List of matrices, each column of which is an observation
void uFPCAClassv2::setCVFold(vec cvFold_){
    cvFold = cvFold_;
}

void uFPCAClassv2::activateCV(int cv_){
    currentCV = cv_;
}

mat uFPCAClassv2::computeMidterm(vec cvFold, int currentCV, vector<vec> yList, vector<mat> bMatList, int index){
    mat tmp;
    size_t totalDF = bMatList.at(0).n_rows;
    size_t totalS = yList.size();
    tmp = mat(totalDF, totalDF, fill::zeros);
    int n,j,k;
    double m_n = 0;
    mat sumI(totalDF, totalDF, fill::zeros);
    
    for (n = 0; n < totalS; n++){
        if (index == 0){ 
            if (cvFold[n] == currentCV) continue;
        } else if (index == 1 ){
            if (cvFold[n] != currentCV) continue;
        } else if (index == 2){
            continue;
        }
        m_n = yList.at(n).n_elem;
        sumI.zeros(); 
        for(j = 0; j < m_n - 1; j++){
            for (k = j+1; k < m_n; k++ ){
                sumI += yList.at(n).at(j) * yList.at(n).at(k) *
                    bMatList.at(n).col(j) * bMatList.at(n).col(k).t();
            }
        }
        tmp += sumI / (m_n * (m_n - 1));
    }
    
    return(tmp);
}


uFPCAClassv2::uFPCAClassv2(vector<vec> y_, vector<mat> bMatList_){
    
    yList = y_;
    bMatList = bMatList_;
    totalS = y_.size();
    
    int n,j,k; 
    double m_n = 0;
    // Init Cross-validation
    currentCV = -1;
    cvFold = ones<vec>(totalS);
    
    totalDF = bMatList_.at(0).n_rows;
    yyBBtSum = mat(totalDF, totalDF, fill::zeros);
    mat sumI(totalDF, totalDF, fill::zeros);
    yyBBtSum_train = mat(totalDF, totalDF, fill::zeros);
    nTotal = 0;
    
    // training mid term
    

    for(n = 0; n < totalS; n++){
        m_n = yList.at(n).n_elem;
        sumI.zeros();
        for(j = 0; j < m_n - 1; j++){
            for(k = j+1; k < m_n; k++ ){
                sumI += yList.at(n).at(j) * yList.at(n).at(k) *
                    bMatList_.at(n).col(j) * bMatList_.at(n).col(k).t();
            }
        }
        yyBBtSum += sumI / (m_n * (m_n - 1));
    }
    
    yyBBtSum_train = computeMidterm(cvFold, currentCV, yList, bMatList, 0);

    
} // uFPCAClassv2

double uFPCAClassv2::outOfBagError(List UWUt){
    arma::mat U,W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    arma::mat BSB;
    mat yyBBtSum_test;
    yyBBtSum_test = mat(totalDF, totalDF, fill::zeros);
    double loss = 0, m_n;
    mat sumI(totalDF, totalDF, fill::zeros);
    int j,k, activeN = 0;
    for (int i=0; i<totalS; i++){
        if (cvFold[i] != currentCV ) continue;
        activeN++;
        m_n = yList.at(i).n_elem;
        BSB = U.t() * bMatList.at(i);
        BSB = BSB.t() * W * BSB;
        BSB = trimatu(BSB, 1);
        loss += dot(BSB, BSB)/ (m_n * (m_n - 1));
        // compute the out of Bag yyBBtSum term
        sumI.zeros();
        for (j = 0; j < m_n - 1; j++){
            for (k = j+1; k < m_n; k++){
                sumI += yList.at(i).at(j) * yList.at(i).at(k) * 
                    bMatList.at(i).col(j) * bMatList.at(i).col(j).t();
            }
        }
        yyBBtSum_test += sumI / (m_n * (m_n - 1));
    }
    loss -= 2.0 * dot(yyBBtSum_test * U, U * W);
    loss /= (2*activeN);
    
    return loss;
}



// Input list: UWUt = U X W
// Output: value of objective function
double uFPCAClassv2::objF(List UWUt){
    arma::mat U,W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1)); 
    arma::mat BSB;
    
    double loss = 0, m_n;
    mat sumI(totalDF, totalDF, fill::zeros);
    int j,k, activeN = 0;
    for (int i=0; i<totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        m_n = yList.at(i).n_elem;
        BSB = U.t() * bMatList.at(i);
        BSB = BSB.t() * W * BSB;
        BSB = trimatu(BSB, 1);
        loss += dot(BSB, BSB)/ (m_n * (m_n - 1));
        // compute the in Bag yyBBtSum term
        /*        sumI.zeros();
        for (j = 0; j < m_n - 1; j++){
            for (k = j+1; k < m_n; k++){
                sumI += yList.at(i).at(j) * yList.at(i).at(k) * 
                    bMatList.at(i).col(j) * bMatList.at(i).col(j).t();
            }
        }
        yyBBtSum += sumI / (m_n * (m_n - 1)); */
    }
    
    loss -= 2.0 * dot(yyBBtSum_train * U, U * W);
    loss /= (2*activeN);
    
    loss += mu1* trace(U.t() * Gamma * U);
    return loss;
}




/* double uFPCAClassv2::objF(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));

    arma::mat BSB;
    double loss = 0, m_n;
    // quadratic loss
    for(int i = 0; i < totalS; i++){
        m_n = yList.at(i).n_elem;
        BSB = U.t() * bMatList.at(i);
        BSB =  BSB.t() * W * BSB;
        BSB = trimatu(BSB, 1);
        loss += dot(BSB, BSB) / (m_n * (m_n-1));
    }
    loss -= 2.0 * dot(yyBBtSum * U, U * W);
    loss /= (2*totalS);
    
    // penalty
    loss += mu1 * trace(U.t()*Gamma*U);
    return loss;
} */

// Input list: UWUt = U X W
// Output list: gradient w.r.t U and W respectively.

List uFPCAClassv2::gradF(List UWUt){
    arma::mat U, W, comp1, comp2, BtBU;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    
    arma::mat coreGrad, grad1, grad2;
    arma::mat BSB, sumI;
    
    coreGrad = -yyBBtSum_train;
    sumI = coreGrad;
    double m_n;
    int i,j,k;
    int activeN = 0;
    //quadratic loss
    for (i = 0; i < totalS; i++){
        if ( cvFold[i] == currentCV) continue;
        activeN++;
        m_n = yList.at(i).n_elem;
        BSB = U.t() * bMatList.at(i);
        BSB =  BSB.t() * W * BSB;
        BSB = trimatu(BSB, 1);
        sumI.zeros();
        for (j = 0; j < m_n - 1; j++){
            for (k = j+1; k < m_n; k++){
                sumI += BSB(j,k) *
                    bMatList.at(i).col(j) * 
                    bMatList.at(i).col(k).t();
            }
        }
        coreGrad += sumI / (m_n * (m_n - 1));
        
    }
    
    coreGrad /= activeN;
    grad1 = 2.0 * coreGrad * U * W;
    grad1 += (2.0*mu1) * Gamma * U;
    
    grad2 = U.t() * coreGrad * U;
    List gradL = List::create(grad1, grad2);
    return gradL;
}

/*
List uFPCAClassv2::gradF(List UWUt){
    arma::mat U, W, comp1, comp2, BtBU;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    
    arma::mat coreGrad, grad1, grad2;
    arma::mat BSB, sumI;
    
    coreGrad = -yyBBtSum;
    sumI = coreGrad;    
    double m_n;
    int i,j,k;
    // quadratic loss
    for(i = 0; i < totalS; i++){
        m_n = yList.at(i).n_elem;
        BSB = U.t() * bMatList.at(i);
        BSB =  BSB.t() * W * BSB;
        BSB = trimatu(BSB, 1);
        sumI.zeros();
        for(j = 0; j < m_n - 1; j++)
            for(k = j+1; k < m_n; k++ )
                sumI += BSB(j,k) *
                    bMatList.at(i).col(j) * 
                    bMatList.at(i).col(k).t();
        coreGrad += sumI / (m_n * (m_n - 1));
    }
    
    coreGrad /= totalS;

    grad1 = 2.0 * coreGrad * U * W;
    grad1 += (2.0*mu1) * Gamma * U;
    
    grad2 = U.t() * coreGrad * U;

    List gradL = List::create(grad1, grad2);
    return gradL;
}
*/

// Objective for Euclidean S withouth penalty.
double uFPCAClassv2::objF_Euc(mat S){
    arma::mat BSB;
    double loss = 0, m_n;
    // quadratic loss
    for(int i = 0; i < totalS; i++){
        m_n = yList.at(i).n_elem;
        BSB =  bMatList.at(i).t() * S * bMatList.at(i);
        BSB = trimatu(BSB, 1);
        loss += dot(BSB, BSB) / (m_n * (m_n-1));
    }
    loss -= 2.0 * dot(yyBBtSum, S);
    loss /= (2*totalS);
    return loss;
}




// Gradient for Euclidean S withouth penalty.
mat uFPCAClassv2::gradF_Euc(mat S){
    arma::mat gradS, sumI;
    gradS = -yyBBtSum;
    sumI = gradS;

    arma::mat BSB;
    double m_n;
    int i,j,k;
    // quadratic loss
    for(i = 0; i < totalS; i++){
        m_n = yList.at(i).n_elem;
        BSB =  bMatList.at(i).t() * S * bMatList.at(i);
        BSB = trimatu(BSB, 1);
        sumI.zeros();
        for(j = 0; j < m_n - 1; j++){
            for(k = j+1; k < m_n; k++ ){
                sumI += BSB(j,k) *
                    bMatList.at(i).col(j) * bMatList.at(i).col(k).t();
            }
        }
        gradS += sumI / (m_n * (m_n - 1));
    }

    gradS /= totalS;
    return gradS;
}



