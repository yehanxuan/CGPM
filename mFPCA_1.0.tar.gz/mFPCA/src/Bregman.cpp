#include "Bregman.hpp"

void mfpcaBreg::setCVFold(vec cvFold_){
    cvFold = cvFold_;
}

void mfpcaBreg::activateCV(int cv_){
    currentCV = cv_;
}

mfpcaBreg::mfpcaBreg(vec y_, mat bMatLarge, double sigmaSq_, vec sCount_, double b_){
    bMatLarge_ = bMatLarge;
    sCount = sCount_;
    totalS = sCount.size();
    
    b = b_;
    // Init Cross-validation
    currentCV = -1;
    cvFold = ones<vec>(totalS);
    
    int startI = -1, endI = -1;
    double m_n = 0, yns;
    vec yn;
    mat Bn, Zn, BnTBn;
    
    totalDF = bMatLarge.n_cols;
    BtZBSum = mat(totalDF, totalDF, fill::zeros);
    sigmaSqLog = std::log(sigmaSq_);
    nTotal = 0;
    for (int n=0; n < totalS; n++){
        m_n = sCount(n);
        nTotal += m_n;
        startI = endI + 1;
        endI = startI + m_n - 1;
        
        yn = y_(span(startI, endI));
        Bn = bMatLarge.rows(startI, endI);
        
        BmatList.push_back(Bn);
        yVecList.push_back(yn);
        yns  = sum(yn % yn);
        YtYList.push_back(yns);
        
        
        BnTBn = Bn.t() * Bn;
        BtB.push_back(BnTBn);
        // Computation saving for MLE
        //YtYListMLE.push_back(dot(yn, yn) );
        //BtBListMLE.push_back(BnTBn);
        //BtYListMLE.push_back(Bn.t() * yn);
        //BtBSumMLE += BnTBn;
    }
}

double mfpcaBreg::outOfBagError(List UWUt){
    arma::mat U, W, comp1, comp2, UtBtBU;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss1 = 0, loss2 = 0, loss = 0, m_i = 0, comp3;
    int activeN = 0;
    mat BtZBSumCV = mat(totalDF, totalDF, fill::zeros);
    //double logdetW, signW;
    //log_det(logdetW, signW, W);
    mat Zi, Pi, PiInv;
    vec tmpY;
    //mat sigmaSqWInv = exp(sigmaSqLog) * inv(W);
    double sigmaSq = exp(sigmaSqLog);
    for (int i = 0; i < totalS; i++){
        if (cvFold[i] != currentCV ) continue;
        // Frob part
        activeN++;
        UtBtBU = U.t() * BtB.at(i) * U;
        comp2 = UtBtBU * W * UtBtBU;
        loss1 += dot(comp2, W);
        m_i = sCount(i);
        Zi = yVecList.at(i) * yVecList.at(i).t();
        // comp3 contain sigmaSq <sigma_e I_n, sigma_e I_n > - 2 <\sigma_e^2I_n, Z_i>
        comp3 = sigmaSq*sigmaSq*m_i - 2*sigmaSq* YtYList.at(i);
        loss1 += comp3;
        Zi.diag() -= sigmaSq;
        BtZBSumCV += BmatList.at(i).t() * Zi * BmatList.at(i);
        // loss function for seed 1/x
        Pi = computePi(U, W, i);
        PiInv = Pi.i();
        tmpY = PiInv * yVecList.at(i);
        loss2 += (-2)*sum(PiInv.diag()) + dot(tmpY, tmpY);
    }
    comp1 = U.t() * BtZBSumCV * U;
    loss1 -= 2.0 * dot(comp1, W);
    loss = (b/2)*loss1 + loss2;
    loss /= static_cast<double>(activeN);
    
    return loss;
}


double mfpcaBreg::objF(List UWUt){
    arma::mat U, W, comp1, comp2, UtBtBU;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss1 = 0, loss2 = 0, loss = 0, m_i = 0, comp3;
    int activeN = 0;
    mat BtZBSumCV = mat(totalDF, totalDF, fill::zeros);
    mat Zi, Pi, PiInv;
    vec tmpY;
    double sigmaSq = exp(sigmaSqLog);
    for(int i = 0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        UtBtBU = U.t() * BtB.at(i) * U;
        comp2 = UtBtBU * W * UtBtBU;
        loss1 += dot(comp2, W);
        m_i = sCount(i);
        Zi = yVecList.at(i) * yVecList.at(i).t();
        // comp3 contain sigmaSq <sigma_e I_n, sigma_e I_n > - 2 <\sigma_e^2I_n, Z_i>
        comp3 = sigmaSq*sigmaSq*m_i - (2.0)*sigmaSq* YtYList.at(i);
        loss1 += comp3;
        Zi.diag() -= sigmaSq;
        BtZBSumCV += BmatList.at(i).t() * Zi * BmatList.at(i);
        
        Pi = computePi(U, W, i);
        PiInv = Pi.i();
        tmpY = PiInv * yVecList.at(i);
        loss2 += (-2.0)*sum(PiInv.diag()) + dot(tmpY, tmpY);
    }
    
    comp1 = U.t() * BtZBSumCV * U;
    loss1 -= 2.0 * dot(comp1, W);
    loss = (b/2.0)*loss1 + loss2;
    loss /= static_cast<double>(activeN);
    
    loss += mu2 * dot(U, Gamma*U);
    return loss;
}

List mfpcaBreg::gradF(List UWUt){
    arma::mat U, W, comp1, BtBU;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    int activeN = 0;
    arma::mat coreGrad, coreGrad1, coreGrad2, grad1, grad2;
    coreGrad1 = BtZBSum;
    coreGrad1.zeros();
    coreGrad2 = zeros(totalDF, totalDF);
    coreGrad = zeros(totalDF, totalDF);
    //mat sigmaSqWInv = exp(sigmaSqLog) * inv(W);
    //mat BtBSumMLECV;
    //BtBSumMLECV = mat(totalDF, totalDF, fill::zeros);
    mat Zi, Pi, PiInv, tmpB, tmp;
    vec tmpY;
    double sigmaSq = exp(sigmaSqLog);
    for (int i = 0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        BtBU = BtB.at(i) * U;
        comp1 = BtBU * W * BtBU.t();
        Zi = yVecList.at(i) * yVecList.at(i).t();
        Zi.diag() -= sigmaSq;
        comp1 -= BmatList.at(i).t() * Zi * BmatList.at(i);
        coreGrad1 += comp1; 
        
        //coreGrad2 += computeKSummand(U, sigmaSqWInv, i);
        //BtBSumMLECV += BtBListMLE.at(i);
        Pi = computePi(U, W, i);
        PiInv = Pi.i();
        tmpY = PiInv * yVecList.at(i);
        tmpB = PiInv * BmatList.at(i);
        tmp = tmpB.t() * tmpY * tmpY.t() * BmatList.at(i);
        coreGrad2 += (2.0) * tmpB.t() * tmpB - tmp - tmp.t();
    }
    
    coreGrad1 *=   (b/2.0);
    coreGrad1 *= (2.0)/static_cast<double>(activeN);
    coreGrad2 /= static_cast<double>(activeN);
    coreGrad = coreGrad1 + coreGrad2;
    
    grad2 = coreGrad * U;
    grad1 = 2 * grad2 * W;
    grad2 = U.t() * grad2 ;
    grad1 += (2*mu2) * Gamma * U;
    List gradL = List::create(grad1, grad2);
    return gradL;
}

void mfpcaBreg::updateSigmaSq(List UWUt, vec params){
    double alpha, beta, epsilon, sigma;
    double res;
    double lambda;
    
    int iter = 0, verbose;
    alpha = params(0);
    beta = params(1);
    sigma = params(2);
    epsilon = params(3);
    verbose = params(4);
    
    do{
        res = updateSigmaSqGradient(UWUt); // compute gradient and hessian
        lambda = updateSigmaSqBackTracking(res, UWUt, alpha, beta, sigma, verbose); // update by back tracking
        if(verbose > 0) Rcout << "Iter = " << iter << "; lambda = " 
                              << lambda << std::endl;
        iter++;
    } while (iter < 30 && lambda > epsilon);
}

// Output: first and second order gradient w.r.t. gamma = log(sigma^2)
double mfpcaBreg::updateSigmaSqGradient(List UWUt){
    arma:mat U, W; 
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double res = 0.0;
    int activeN = 0;
    mat Pi, PiInv;
    vec tmpY;
    double grad = 0.0, grad1 = 0.0, grad2 = 0.0, hess = 0.0;
    for (int i = 0; i < totalS; i++){ 
        if (cvFold[i] == currentCV ) continue;
        activeN++;
        Pi = computePi(U, W, i);
        PiInv = Pi.i();
        tmpY = PiInv * yVecList.at(i);
        
        grad1 += (2.0)* (dot(PiInv, PiInv) - dot(tmpY, PiInv * tmpY) );
        // Frobenious 
        grad2 += b * ( sum(Pi.diag()) -  YtYList.at(i) );
        
    }
    grad = grad1 + grad2;
    grad /= static_cast<double>(activeN);
    res = grad * std::exp(sigmaSqLog);
    return res;
}

double mfpcaBreg::updateSigmaSqBackTracking(double res, List UWUt,
                                            double alpha, double beta, double sigma, int verbose){
    double grad;
    grad = res;
    
    double objV, objVOld, sigmaSqLogOld, lambda;
    double stepsize = 2, expectedDesc, actualDesc;
    int iterInner = 0;
    
    lambda = grad * grad;
    expectedDesc = lambda / beta * alpha * sigma; 
    sigmaSqLogOld = sigmaSqLog;
    objVOld = objF(UWUt);
    do{
        sigmaSqLog = sigmaSqLogOld - stepsize * grad ;
        objV = objF(UWUt);
        actualDesc = objVOld - objV;
        iterInner++;
        stepsize *= beta;
        expectedDesc *= beta;
        if( verbose > 1)
            Rcout << iterInner << " " << expectedDesc << 
                " " << actualDesc << std::endl;
    } while (iterInner < 50 & actualDesc < expectedDesc);
    
    return lambda;
}



