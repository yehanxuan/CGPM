#include "Power.hpp"

void mfpcaPower::setCVFold(vec cvFold_){
    cvFold = cvFold_;
}


void mfpcaPower::activateCV(int cv_){
    currentCV = cv_;
}

mfpcaPower::mfpcaPower(vec y_, mat bMatLarge, double sigmaSq_, vec sCount_, double b_){
    bMatLarge_ = bMatLarge;
    sCount = sCount_;
    totalS = sCount.size();
    
    b = b_;
    // Init Cross-validation
    currentCV = -1;
    cvFold = ones<vec>(totalS);
    
    int startI = -1, endI = -1;
    double m_n = 0, yns;
    vec yn;
    mat Bn, Zn, BnTBn;
    
    totalDF = bMatLarge.n_cols;
    BtZBSum = mat(totalDF, totalDF, fill::zeros);
    sigmaSqLog = std::log(sigmaSq_);
    nTotal = 0;
    for (int n=0; n < totalS; n++){
        m_n = sCount(n);
        nTotal += m_n;
        startI = endI + 1;
        endI = startI + m_n - 1;
        
        yn = y_(span(startI, endI));
        Bn = bMatLarge.rows(startI, endI);
        
        BmatList.push_back(Bn);
        yVecList.push_back(yn);
//       yns  = sum(yn % yn);
//        YtYList.push_back(yns);
        
        
 //       BnTBn = Bn.t() * Bn;
 //       BtB.push_back(BnTBn);
        // Computation saving for MLE
        //YtYListMLE.push_back(dot(yn, yn) );
        //BtBListMLE.push_back(BnTBn);
        //BtYListMLE.push_back(Bn.t() * yn);
        //BtBSumMLE += BnTBn;
    }
}

double mfpcaPower::outOfBagError(List UWUt){
    arma:mat U,W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss = 0;
    int activeN = 0;
    double sigmaSq = exp(sigmaSqLog);
    for (int i = 0; i < totalS; i++){
        if (cvFold[i] != currentCV ) continue;
        activeN++;
        mat Pi = computePi(U, W, i);
        vec eigval;
        mat eigvec;
        eig_sym(eigval, eigvec, Pi);
        vec h = eigvec.t() * yVecList.at(i);
        loss +=  as_scalar( b/(1-b) * sum( pow(eigval, 1-b)) +  h.t() * ( pow(eigval, -b) % h )) ;
        }
    loss /= static_cast<double>(activeN);
    return loss;
}

double mfpcaPower::objF(List UWUt){
    arma:mat U,W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double loss = 0;
    int activeN = 0;
    double sigmaSq = exp(sigmaSqLog);
    for (int i = 0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        mat Pi = computePi(U, W, i);
        vec eigval;
        mat eigvec;
        eig_sym(eigval, eigvec, Pi);
        vec h = eigvec.t() * yVecList.at(i);
        loss += as_scalar( ( b/(1-b) * sum( pow(eigval, 1-b)) +  h.t() * ( pow(eigval, -b) % h )) );
    }
    loss /= static_cast<double>(activeN);
    loss += mu2 * dot(U, Gamma*U);
    return loss;
}


List mfpcaPower::gradF(List UWUt){
    arma::mat U, W;
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    arma::mat coreGrad, grad1, grad2;
    coreGrad = zeros(totalDF, totalDF);
    int activeN = 0;
    double sigmaSq = exp(sigmaSqLog);
    
    for (int i=0; i < totalS; i++){
        if (cvFold[i] == currentCV) continue;
        activeN++;
        mat Pi = computePi(U, W, i);
        coreGrad  += computeCore(Pi, i);
    }
    
    coreGrad /= activeN;
    grad2 = coreGrad * U; 
    grad1 = 2 * grad2 * W; 
    grad2 = U.t() * grad2; 
    grad1 += (2*mu2) * Gamma * U;
    List gradL = List::create(grad1, grad2);
    return gradL;
}

void mfpcaPower::updateSigmaSq(List UWUt, vec params){
    double alpha, beta, epsilon, sigma;
    double res;
    double lambda;
    
    int iter = 0, verbose;
    alpha = params(0);
    beta = params(1);
    sigma = params(2);
    epsilon = params(3);
    verbose = params(4);
    
    do{
        res = updateSigmaSqGradient(UWUt); // compute gradient and hessian
        lambda = updateSigmaSqBackTracking(res, UWUt, alpha, beta, sigma, verbose); // update by back tracking
        if(verbose > 0) Rcout << "Iter = " << iter << "; lambda = " 
                              << lambda << std::endl;
        iter++;
    } while (iter < 30 && lambda > epsilon);
}

double mfpcaPower::updateSigmaSqGradient(List UWUt){
    arma:mat U, W; 
    U = as<arma::mat>(UWUt(0));
    W = as<arma::mat>(UWUt(1));
    double res = 0.0;
    int activeN = 0;
    double sigmaSq = exp(sigmaSqLog);
    double grad = 0.0;
    
    for (int i=0; i < totalS; i++){
        if (cvFold[i] == currentCV ) continue;
        activeN++;
        mat Pi = zeros(sCount(i), sCount(i));
        Pi = BmatList.at(i)* U * W * U.t() * BmatList.at(i).t();
        Pi.diag() += sigmaSq;
        vec eigval;
        mat eigvec;
        eig_sym(eigval, eigvec, Pi);
        vec h = eigvec.t() * yVecList.at(i);
        mat PhiG_n = DerivMat(eigval);
        int n = eigval.n_elem;
        grad -= trace( ( h * h.t() ) % PhiG_n );
        grad += as_scalar( sum( b * pow(eigval, -b) )); 
    }
    grad /= activeN;
    res = grad * std::exp(sigmaSqLog);
    return res;
}

double mfpcaPower::updateSigmaSqBackTracking(double res, List UWUt,
                                             double alpha, double beta,
                                             double sigma,
                                             int verbose){
    double grad;
    grad = res;
    
    double objV, objVOld, sigmaSqLogOld, lambda;
    double stepsize = 5, expectedDesc, actualDesc;
    int iterInner = 0;
    
    lambda = grad * grad;
    expectedDesc = lambda / beta * alpha * sigma;
    sigmaSqLogOld = sigmaSqLog;
    objVOld = objF(UWUt);
    do{
        sigmaSqLog = sigmaSqLogOld - stepsize * grad ;
        objV = objF(UWUt);
        actualDesc = objVOld - objV;
        iterInner++;
        stepsize *= beta;
        expectedDesc *= beta;
        if( verbose > 1)
            Rcout << iterInner << " " << expectedDesc << 
                " " << actualDesc << std::endl;
    } while (iterInner < 50 & actualDesc < expectedDesc);
    
    return lambda;
}


