## observation ID, n = 1, .. , N
## observation element ID, each obs has Q vector elements 
## observation obsT(time), obsY (value), obsSigma (uncertainty)
## everything sorted by obsID

#' Create MFPCA objective function
#' @param dataF the data frame of the observation data. This should have four columns.
#' obsID vector of observation ID
#' elemID vector of observation vector element ID (Factor, optional)
#' obsT vector of observation time points
#' obsY vector of observation value
#' @param obsSigma double, FPCA residual sigma
#' @param splineObj spline object 
#' @return an object of the class MFPCLoss, 
#' the objective and gradient function can be evaluated.
#' 
#' The elemID is optional. If not specified, the result is univariate FPCA.
createMFPCAObjMLE = function(dataF, splineObj, obsSigma = 1){
    if(is.character(dataF$obsID))
        dataF$obsID = factor(dataF$obsID, ordered = TRUE)
    if(is.factor(dataF$obsID))
        dataF$obsID = as.numeric(dataF$obsID)
    sortI = sort(dataF$obsID, index.return = TRUE)$ix
    obsID = dataF$obsID[sortI]
    
    elemID = dataF$elemID[sortI]
    obsT = dataF$obsT[sortI]
    ## Add grids in EM here
    #### rescale obsT to grids in EM 
    
    grids= seq(0,1,0.002)
    timeindex = floor(obsT * length(grids)) + 1
    obsT = grids[timeindex]
    
    obsY = dataF$obsY[sortI]
    # obsSigma = obsSigma[sortI]
    
    ## The number of points for each obs ID
    obsIDCount = as.numeric(table(obsID)) 
    
    bMatLarge = generate_bMatLarge(obsT, elemID, splineObj)
    
    # smoothness penalty
    Omega = splineObj$get_Omega()
    
    # the number of multivariate components
    elemNum = length(unique(elemID))
    Gamma = Omega
    if(elemNum > 1){
        for(e in 2:elemNum)
            Gamma = bdiag(Gamma, Omega)
    }
    Gamma = as.matrix(Gamma)
    
    optObj = new(mfpcaMLE, obsY, bMatLarge, obsSigma, obsIDCount)
    optObj$set_penaltyMatrix(Gamma)
    return(optObj)
}





#' @param obsData the data frame for the observation data.
#' @param splineObj the spline object for training.
#' @param optRank Select the rank for model fitting.
#' @param mu2 the tuning parameter for smoothness penalty.
#' @param controlList1 the control parameter for the first round of optimization.
#' @param controlList2 the control parameter for the second round of optimization.
#' @param SInit Initial Value
#' @param sigmaSq the initial value for sigma squared
MFPCA_EstimateMLE = function(obsData, splineObj, 
                             optRank, mu,
                             controlList1 = NULL,
                             controlList2 = NULL,
                             SInit = NULL, sigmaSq = 1, eigenfList = NULL){
    tmin = splineObj$getTMin()
    tmax = splineObj$getTMax()
    
    # Check the existence of the column elemID.
    # If not there, this is the univariate FPCA
    if(is.null(obsData$elemID)){
        obsData$elemID = factor(rep(1,length(obsData$obsY)))
    }else{
        obsData$elemID = factor(obsData$elemID)
    }
    
    trainObj = createMFPCAObjMLE(obsData, splineObj, sigmaSq)

    #controlList = list(alpha = 0.5, tol = 1e-4, iterMax = 100)
    
    # Roughness penalty
    trainObj$set_tuningParameter(mu)
    
    if(is.null(SInit))
        SInit = MFPCA_Initial(trainObj, optRank, controlList1 )
    
    estimate = MFPCA_SecondMLE(trainObj, optRank, controlList2, SInit, splineObj, eigenfList)
    sigmaSq =  trainObj$get_sigmaSq() 
    
    SFinal = estimate$SEstimate
    step = estimate$iter
    like = estimate$obj
    gap = estimate$gap
    Time = estimate$Time
    loss = estimate$lossVec
    
    YVec = estimate$YVec
    # convert matrices SFinal to R functions
    numElem = length(levels(obsData$elemID))
    model = MFPCA_convert(SFinal, splineObj, optRank, numElem)
    model = c(model, 
              list(tmin = tmin, tmax = tmax,
                   SFinal = SFinal, sigmaSq = sigmaSq,
                   numPCA = optRank, numElem = numElem,
                   elemLevels = levels(obsData$elemID), YVec = YVec, step = step, like = like, gap = gap, Time = Time, loss = loss))
    
    return(model)
}



# Second step estimation on the manifold
MFPCA_SecondMLE = function(optObj, optRank, controlList, SInit, splineObj = NULL, eigenfList = NULL ){
    SEstimate = SInit
    iter = 0
    flag = TRUE
    gap = 1
    tol = 1e-3
    params = c(0.1, 0.618, 0.01, 0.1,0)
    obj = optObj$objF(SEstimate)
    objVector = c(obj)
  #  Time = c(0, 0, 0)
    Time = 0
    YVec = list()
    YVec[[1]] = SInit
    if (!is.null(splineObj)){
        loss = list()
        #loss = mean( ComputeLoss_S(SInit, eigenfList, splineObj ))
        if (!is.null(eigenfList)){
          loss[[1]] = ComputeLoss_S(SInit, eigenfList, splineObj)
        }
    }
    while(gap > tol){
     #   iter = iter + 1   
     #   start = proc.time()
        Fit = MFPCA_SecondCore(optObj, optRank, controlList, SEstimate)
        SEstimate = Fit$SFinal
        objVector = c(objVector, Fit$objVec)
        Time = c(Time, Fit$timeVec)
        iter = iter + length(Fit$timeVec)
        YVec = c(YVec, Fit$SVec)
     #   losstmp = ComputeLoss_SVec(Fit$SVec, eigenfList, splineObj)
      #  loss = c(loss, losstmp)
        optObj$updateSigmaSq(SEstimate, params)
      #  if (!is.null(splineObj)){
      #      # loss = c(loss, mean(ComputeLoss_S(SEstimate, eigenfList, splineObj) ) )
      #      loss[[iter+1]]  = ComputeLoss_S(SEstimate, eigenfList, splineObj)
      #  }
      #    Interval = proc.time() - start 
     #    Time = rbind(Time, Interval[1:3])
        obj_new = optObj$objF(SEstimate)
    #    objVector = c(objVector, obj_new)
        gap = obj - obj_new 
        obj = obj_new
     
   }
   # Time = as.matrix(Time)
   # TimeMatrix = apply(Time, 2, cumsum)
    TimeMatrix = cumsum(Time)
    iter = iter + 1
#    SEstimate = MFPCA_SecondCore(optObj, optRank, controlList, SEstimate)
    #SHat = SEstimate[[1]] %*% SEstimate[[2]] %*% t(SEstimate[[1]])
#    params = c(0.1, 0.618, 0.01, 0.1,0)
#    optObj$updateSigmaSq(SEstimate, params)
#    SEstimate = MFPCA_SecondCore(optObj, optRank, controlList, SEstimate)
    
    #sigmaSq = optObj$get_sigmaSq()
    #while(iter < 3 & flag){
        #SEstimate = MFPCA_SecondCore(optObj, optRank, controlList, SEstimate)
        #SHat = SEstimate[[1]] %*% SEstimate[[2]] %*% t(SEstimate[[1]])
        #params = c(0.1, 0.618, 0.01, 0.1,0)
        #optObj$updateSigmaSq(SEstimate, params)
        #sigmaSqNew = optObj$get_sigmaSq()
        #if(sigmaSqNew < 0) sigmaSqNew = 0
        #diffSigma = abs(sigmaSqNew - sigmaSq) / max(sigmaSq,1)
        #if(diffSigma < 0.01) flag = FALSE
        #sigmaSq = sigmaSqNew
        #iter = iter + 1
        #cat(iter, diffSigma, "\n")
    #}
    return(list(SEstimate = SEstimate, iter = iter, obj = objVector, gap = gap, Time = TimeMatrix, lossVec = loss, YVec = YVec))
}



# Initial value estimation in the Euclidean space
MFPCA_Initial = function(optObj, optRank, controlList){
    #list(alpha = 1e3, sigma = 0.5, tol = 1e-4, iterMax = 30)
    # total DoF, with component number included.
    splineDF = optObj$get_totalDF()
    
    problem = new(manifoldOpt)
    problem$set_euclidean(splineDF, splineDF)
    # The euclidean loss version
    problem$setObjective(optObj$objF_Euc)
    problem$setGradient(optObj$gradF_Euc)
    problem$update_control(controlList)
    problem$solve()
    SInit = problem$get_optimizer()
    SInit = (SInit + t(SInit)) / 2.0 
    SInit_eigen = eigen(SInit)
    UInit = SInit_eigen$vectors[,1:optRank]
    WInit = SInit_eigen$values[1:optRank]
    mm = min(WInit[WInit>0])
    WInit[WInit <= 0] = mm
    XInit = list(UInit, 
                 diag(WInit))
    return(XInit)
}




MFPCA_SecondCore = function(optObj, optRank,  controlList, XInit){
    #list(alpha = 1e-2, sigma = 1e-2, tol = 1e-10,
    #        iterMax = 400, iterSubMax = 30)
    
    splineDF = optObj$get_totalDF()
    problem = new(manifoldOpt)
    problem$select_algorithm("cg")
    problem$set_eigenReg(splineDF, optRank)
    
    # The manifold loss version
    problem$setObjective(optObj$objF)
    problem$setGradient(optObj$gradF)
    problem$initial_point(XInit)
    problem$update_control(controlList)
    problem$solve()
    SFinal = problem$get_optimizer()
    objValueVec = problem$get_objValueVec()
    YVec = problem$get_YVec()
    timeVec = problem$get_timeVec()
    # timeVec = cumsum(timeInterval)
    return(list("SFinal" = SFinal, "objVec" = objValueVec, "SVec" = YVec, "timeVec" = timeVec))
} 




