# Manifold Application 
The package now provides wrappping functions for 

1. Functional Additive Model
2. Multivariate Functional Principal Component Analysis

Other extensions
1. Orthonormalized B-spline basis
2. mFPCA with EM algorithm