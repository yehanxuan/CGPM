load("~/Downloads/Data_NormV.RData")

k = 365
plot(Data$wavelength[[k]], Data$y[[k]], type = "l", ylim = c(-2,2))
lines(Data$wavelength[[k]], Data$W[[k]][,201])

length(Data$wavelength)
hist(Data$Infor[[6]])

length(Data$wavelength[[k]])

# Zeros columns in W, what is the impact?
