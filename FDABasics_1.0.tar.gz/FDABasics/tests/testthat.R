library(testthat)
library(FDABasics)

test_check("FDABasics")
