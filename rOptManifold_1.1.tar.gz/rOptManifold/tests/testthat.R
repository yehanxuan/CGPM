library(testthat)
library(rOptManifold)
test_check("rOptManifold")
