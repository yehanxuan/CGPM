## Problem to solve
 
1. Repeated evaluation of retraction. Store information. Create auxiliary variable in ```tangent_vector```
2. Product of tangent vectors. Naming convetion.


